<div id="powered-by">
	<?php _e('Powered by', 'usernoise') ?>
	<a href="http://codecanyon.net/item/usernoise-pro-advanced-modal-feedback-debug/1420436?ref=karevn" title="WordPress contact form plugin" target="_blank"><?php _e('Usernoise Pro', 'usernoise-pro') ?></a>
</div>