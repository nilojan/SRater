<li class="blank-slate">
	<?php _e('No comments yet.') ?>
</li>