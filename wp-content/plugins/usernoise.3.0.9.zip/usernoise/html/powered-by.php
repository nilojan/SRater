<div id="powered-by">
	<?php _e('Powered by', 'usernoise') ?>
	<a href="http://wordpress.org/extend/plugins/usernoise/" target="_new" title="WordPress contact form plugin">Usernoise</a>
</div>