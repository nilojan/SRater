<a id="un-button" href="#" style="background-color: <?php echo un_get_option(UN_FEEDBACK_BUTTON_COLOR) ?>; color: <?php echo un_get_option(UN_FEEDBACK_BUTTON_TEXT_COLOR) ?>" <?php un_button_class() ?>>
	<?php un_feedback_button_text() ?>
</a>